# Agent Hub — รวม pure-agent-dev + crystalcastle-ai + claude-code

ทำเท่าที่ทำได้ก่อน (ตามที่คุณบอก) — ผมสร้างโครง starter ให้แล้ว โดยยังไม่ใส่โค้ด private ของ crystalcastle

## มีอะไรในนี้
- apps/web — Next.js 14 พร้อม deploy Vercel
- packages/core — agent registry, routing
- packages/pure-agent — ที่วางโค้ด pure-agent-dev
- packages/crystalcastle — ที่วางโค้ด private ของคุณ (ตอนนี้เป็น placeholder)
- packages/claude-code — harness สำหรับ Claude Code
- supabase/schema.sql — ตาราง agents, sessions, memory
- vercel.json — config

## วิธีต่อ
1. แตก zip
2. เอาโค้ดจาก crystalcastle.zip ใส่ใน packages/crystalcastle/
3. ตั้ง .env: SUPABASE_URL, SUPABASE_ANON_KEY, ANTHROPIC_API_KEY
4. pnpm install && pnpm dev
